CREATE DATABASE ecommerce_project;
USE ecommerce_project;
