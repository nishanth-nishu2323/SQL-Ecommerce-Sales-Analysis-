# 📊 Project Overview – E-Commerce Sales Analysis

## Objective
Design a relational database and analyze business performance using SQL.

## Business Problems Solved
- Total revenue calculation
- Top customers identification
- Monthly sales analysis
- Best-selling products
